/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_syntax_check.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nali <nali@42abudhabi.ae>                  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/24 11:38:50 by nali              #+#    #+#             */
/*   Updated: 2022/06/25 10:00:54 by nali             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

int	ft_check_next_token(char *str)
{
	if (!str)
	{
		printf("minishell: syntax error near unexpected token `newline'\n");
		g_err = 258;
		return (1);
	}
	if (ft_strcmp(str, "<<") || ft_strcmp(str, "<") || ft_strcmp(str, "|") \
	|| ft_strcmp(str, ">>") || ft_strcmp(str, ">"))
	{
		printf("minishell: syntax error near unexpected token `%s'\n", str);
		g_err = 258;
		return (1);
	}
	return (0);
}

int	ft_syntax_check_2(char **tokens, int i)
{
	if (ft_strcmp(tokens[i], "<") && ft_check_next_token(tokens[i + 1]))
		return (1);
	if (ft_strcmp(tokens[i], "<<") && ft_check_next_token(tokens[i + 1]))
		return (1);
	if (ft_strcmp(tokens[i], ">") && ft_check_next_token(tokens[i + 1]))
		return (1);
	if (ft_strcmp(tokens[i], ">>") && ft_check_next_token(tokens[i + 1]))
		return (1);
	if (ft_strcmp(tokens[i], "|") && tokens[i + 1] \
	&& ft_strcmp(tokens[i + 1], "|"))
	{
		printf("minishell: syntax error near unexpected token `|'\n");
		g_err = 258;
		return (1);
	}
	return (0);
}

int	ft_syntax_check(char **tokens)
{
	int	i;

	i = 0;
	if (tokens[0] && tokens[0][0] && tokens[0][0] == '|')
	{
		printf("minishell: syntax error near unexpected token `|'\n");
		g_err = 258;
		return (1);
	}
	while (tokens[i])
	{
		if (ft_syntax_check_2(tokens, i) == 1)
			return (1);
		i++;
	}
	if (tokens[i - 1] && tokens[i - 1][0] == '|')
	{
		g_err = 0;
		printf("minishell: format not supported\n");
		return (1);
	}
	return (0);
}
