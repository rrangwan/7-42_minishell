/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_export3.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nali <nali@42abudhabi.ae>                  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/17 04:18:17 by rrangwan          #+#    #+#             */
/*   Updated: 2022/06/23 17:39:28 by nali             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

//checks if = present
//checks for syntax of assignement
int	ft_is_export(char **cmd)
{
	int		i;
	int		j;

	i = 1;
	j = 0;
	while (cmd[i] && cmd[i] != NULL)
	{
		if (ft_export7(cmd[i]) == 0)
			j++;
		if (cmd[i] != NULL)
			if (ft_is_export3(cmd[i]) == 1)
				return (1);
		i++;
	}
	if ((ft_array_len(cmd) - 1) == j)
		return (1);
	return (0);
}

//checks if cmd starts with =
int	ft_is_export3(char *cmd)
{
	char	*ret;

	if (cmd[0] == '=')
	{
		ret = ft_export6(cmd);
		ft_putstr_fd("export: '=", 2);
		ft_putstr_fd(ret, 2);
		ft_putstr_fd("' not a valid identifier\n", 2);
		free(ret);
		return (1);
	}
	return (0);
}
