/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_cd4.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nali <nali@42abudhabi.ae>                  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/21 00:43:50 by rrangwan          #+#    #+#             */
/*   Updated: 2022/06/26 10:02:23 by nali             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

void	ft_cd(char **cmd, t_var *vars)
{
	char	*dir;
	char	old_pwd[300];

	getcwd(old_pwd, sizeof(old_pwd));
	dir = getenv("HOME");
	if (cmd[1] != NULL && cmd[2] != NULL)
	{
		ft_putstr_fd("cd: too many arguments\n", 2);
		g_err = 1;
		exit(g_err);
	}
	else
		ft_cd3(cmd, vars, dir, old_pwd);
}

void	ft_cd_parent(char **cmd, t_var *vars)
{
	char	*dir;
	char	old_pwd[300];

	getcwd(old_pwd, sizeof(old_pwd));
	dir = getenv("HOME");
	if (cmd[1] != NULL && cmd[2] != NULL)
	{
		ft_putstr_fd("cd: too many arguments\n", 2);
		g_err = 1;
		return ;
	}
	else
		ft_cd3_parent(cmd, vars, dir, old_pwd);
}
