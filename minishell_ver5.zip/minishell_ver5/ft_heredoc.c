/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_heredoc.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nali <nali@42abudhabi.ae>                  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/23 11:42:47 by nali              #+#    #+#             */
/*   Updated: 2022/06/27 10:53:35 by nali             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

void	ft_write_to_pipe(char **arr, int *fd)
{
	int	i;
	int	len;

	i = 0;
	while (arr[i])
	{
		len = ft_strlen(arr[i]);
		write(fd[1], arr[i], len);
		write(fd[1], "\n", 1);
		i++;
	}
	close(fd[1]);
	close(fd[0]);
	ft_free_array(arr);
}

/*	If any part of limiter is quoted, the delimiter shall be formed by 
	performing quote removal on limiter, and the here-document lines 
	shall not be expanded. Otherwise, the delimiter shall be the 'limiter' itself.
	If no part of limiter is quoted, all lines of the here-document 
	shall be expanded for parameter expansion, command subst
	and arithmetic expansion. 
	quote_count store number of quotes*/
char	**ft_heredoc(int index, t_cmd *node, t_var *vars, int count)
{
	char	**arr;
	int		fd[2];
	int		id;
	int		status;

	pipe(fd);
	signal(SIGINT, SIG_IGN);
	id = fork();
	if (id == -1)
		return (NULL);
	if (id == 0)
	{
		arr = ft_read_stdin(node->cmd[index + 1]);
		if (count == 0)
			ft_heredoc_expansion(arr, vars);
		ft_write_to_pipe(arr, fd);
		exit(0);
	}
	close(fd[1]);
	wait(&status);
	node->here_fd = fd[0];
	count = 0;
	while (node->cmd[count])
		count++;
	return (ft_remove_redirection(node->cmd, count, index));
}

/*------------- HEREDOC HANDLING -------------*/
/*	If << is present, read from STDIN and save in a pipe*/
int	ft_handle_heredoc(t_cmd *node, t_var *vars)
{
	int		i;
	int		count;
	char	**new_cmd;

	i = -1;
	while (node->cmd[++i])
	{
		if (ft_strcmp(node->cmd[i], "<<") == 1)
		{
			if (node->here_fd != STDIN_FILENO)
				close(node->here_fd);
			if (ft_check_next_token(node->cmd[i + 1]) == 1)
				return (1);
			count = ft_count_quotes(node->cmd[i + 1]);
			node->cmd[i + 1] = ft_trim_2(node->cmd[i + 1]);
			new_cmd = ft_heredoc(i, node, vars, count);
			ft_free_array(node->cmd);
			node->cmd = new_cmd;
			i = -1;
		}
	}
	return (0);
}
