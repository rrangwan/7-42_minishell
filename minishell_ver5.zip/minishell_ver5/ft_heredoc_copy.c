/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_heredoc.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nali <nali@42abudhabi.ae>                  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/23 11:42:47 by nali              #+#    #+#             */
/*   Updated: 2022/06/27 09:32:38 by nali             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

char	*ft_add_newline(char *buf)
{
	char	*str;

	if (!*buf)
	{
		free(buf);
		buf = (char *)malloc(2);
		buf[0] = '\n';
		buf[1] = '\0';
		return (buf);
	}
	str = ft_strjoin(buf, "\n");
	free(buf);
	return (str);
}

/*------------- READ FROM STDIN AND STORE IN 2D ARRAY -------------*/
char	**ft_read_stdin(char *limiter)
{
	char	*str;
	char	*final;
	char	*tmp;
	char	**arr;

	signal(SIGINT, ft_sig_handler_heredoc);
	arr = NULL;
	str = readline(">");
	if (str == NULL)
		return (NULL);
	final = ft_strdup(str);
	while (ft_strcmp(str, limiter) != 1 && str != NULL)
	{
		free(str);
		str = readline(">");
		if (ft_strcmp(str, limiter) != 1 && str != NULL)
		{
			tmp = ft_add_newline(final);
			final = ft_strjoin(tmp, str);
			free(tmp);
		}
	}
	free(str);
	if (ft_strcmp(final, limiter) != 1)
		arr = ft_split(final, '\n');
	free(final);
	return (arr);
}

// char	**ft_read_stdin(char *limiter)
// {
// 	char	*str;
// 	char	*final;
// 	char	*tmp;
// 	char	**arr;

// 	str = readline(">");
// 	if (str == NULL)
// 		return (NULL);
// 	final = ft_strdup(str);
// 	while (ft_strcmp(str, limiter) != 1 && str != NULL)
// 	{
// 		free(str);
// 		str = readline(">");
// 		if (ft_strcmp(str, limiter) != 1 && str != NULL)
// 		{
// 			tmp = ft_add_newline(final);
// 			final = ft_strjoin(tmp, str);
// 			free(tmp);
// 		}
// 	}
// 	free(str);
// 	arr = ft_split(final, '\n');
// 	free(final);
// 	// signal(SIGINT, ft_sig_handler);
// 	return (arr);
// }

void	ft_write_to_pipe(char **arr, int fd)
{
	int	i;
	int	len;

	i = 0;
	if (arr == NULL)
		return ;
	while (arr[i])
	{
		len = ft_strlen(arr[i]);
		write(fd, arr[i], len);
		write(fd, "\n", 1);
		i++;
	}
}

/*	If any part of limiter is quoted, the delimiter shall be formed by 
	performing quote removal on limiter, and the here-document lines 
	shall not be expanded. Otherwise, the delimiter shall be the 'limiter' itself.
	If no part of limiter is quoted, all lines of the here-document 
	shall be expanded for parameter expansion, command subst
	and arithmetic expansion. 
	quote_count store number of quotes*/
char	**ft_heredoc(char **cmd, int index, t_cmd *node, t_var *vars)
{
	int		count;
	char	**new_cmd;
	char	**arr;
	int		fd[2];
	int		quote_count;

	quote_count = ft_count_quotes(cmd[index + 1]);
	cmd[index + 1] = ft_trim_2(cmd[index + 1]);
	arr = ft_read_stdin(cmd[index + 1]);
	if (quote_count == 0)
		ft_heredoc_expansion(arr, vars);
	if (arr == NULL)
		return (NULL);
	pipe(fd);
	ft_write_to_pipe(arr, fd[1]);
	close(fd[1]);
	node->here_fd = fd[0];
	ft_free_array(arr);
	count = 0;
	while (cmd[count])
		count++;
	new_cmd = ft_remove_redirection(cmd, count, index);
	ft_free_array(cmd);
	return (new_cmd);
}

/*------------- HEREDOC HANDLING -------------*/
/*	If << is present, read from STDIN and save in a pipe*/
int	ft_handle_heredoc(t_cmd *node, t_var *vars)
{
	int		i;
	char	**str;

	i = 0;
	while (node->cmd[i])
	{
		if (ft_strcmp(node->cmd[i], "<<") == 1)
		{
			if (node->here_fd != STDIN_FILENO)
				close(node->here_fd);
			if (ft_check_next_token(node->cmd[i + 1]) == 1)
				return (1);
			str = ft_heredoc(node->cmd, i, node, vars);
			if (str == NULL)
				return (1);
			node->cmd = str;
			i = -1;
		}
		i++;
	}
	return (0);
}
