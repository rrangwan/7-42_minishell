/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_heredoc.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nali <nali@42abudhabi.ae>                  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/23 11:42:47 by nali              #+#    #+#             */
/*   Updated: 2022/06/23 07:55:54 by nali             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

/*------------- READ FROM STDIN AND WRITE TO TMP_FILE -------------*/
int	ft_read_stdin(char *limiter, int fd)
{
	int		len;
	char	*str;

	str = readline(">");
	while (ft_strcmp(str, limiter) != 1 && str != NULL)
	{
		str = ft_add_newline(str);
		len = ft_strlen(str);
		write(fd, str, len);
		free(str);
		str = readline(">");
	}
	free(str);
	return (1);
}

/*------------- << OPERATOR -------------*/
/*	1. 	If present store that string as limiter
	2. 	Then remove << operator and limiter from the command array*/
char	**ft_heredoc(char **cmd, int index, int *fd)
{
	int		count;
	char	**new_cmd;
	int		pipe_fd[2];

	pipe(pipe_fd);
	if (ft_read_stdin(cmd[index + 1], pipe_fd[1]) == 0)
	{
		close(fd[0]);
		close(fd[1]);
		printf("minishell: Error reading from std input.\n");
		g_err = 1;
		return (NULL);
	}
	close(pipe_fd[1]);
	*fd = pipe_fd[0];
	count = 0;
	while (cmd[count])
		count++;
	new_cmd = ft_remove_redirection(cmd, count, index);
	ft_free_array(cmd);
	return (new_cmd);
}

/*------------- CHECK IF LAST REDIR IS < or << -------------*/
void	ft_input_redir_order(t_cmd *node)
{
	int		i;

	i = 0;
	while (node->cmd[i])
	{
		if (ft_strcmp(node->cmd[i], "<") == 1)
			node->here_doc = 0;
		if (ft_strcmp(node->cmd[i], "<<") == 1)
			node->here_doc = 1;
		i++;
	}
}

/*------------- HEREDOC HANDLING -------------*/
/*	If << is present, read from STDIN and save in a pipe*/
int	ft_handle_heredoc(t_cmd *node)
{
	int		i;
	char	**str;

	i = 0;
	while (node->cmd[i])
	{
		if (ft_strcmp(node->cmd[i], "<<") == 1)
		{
			if (!node->cmd[i + 1])
			{
				printf("minishell: syntax error\n");
				g_err = 258;
				return (1);
			}
			if (node->heredoc_fd != STDIN_FILENO)
				close(node->here_doc);
			str = ft_heredoc(node->cmd, i, &node->heredoc_fd);
			if (str == NULL)
				return (1);
			node->cmd = str;
			i = -1;
		}
		i++;
	}
	return (0);
}