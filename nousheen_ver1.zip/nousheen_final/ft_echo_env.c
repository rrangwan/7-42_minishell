/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_echo_env.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nali <nali@42abudhabi.ae>                  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/17 11:19:17 by nali              #+#    #+#             */
/*   Updated: 2022/06/21 15:04:05 by nali             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

void	ft_echo2(char **cmd, int fd)
{
	int		j;
	int		flag;

	j = 1;
	flag = 0;
	if (cmd[1][0] == '-' && cmd[1][1] == 'n' && cmd[1][2] == '\0')
	{
		flag = 1;
		j++;
	}
	while (cmd[j])
	{
		ft_putstr_fd(cmd[j], fd);
		j++;
		if (cmd[j])
			ft_putchar_fd(' ', fd);
	}
	if (!flag)
		ft_putchar_fd('\n', fd);
	g_err = 0;
	exit(g_err);
}

void	ft_echo(char **cmd, int fd)
{
	if (!cmd[1])
	{
		printf("\n");
		g_err = 0;
		exit(g_err);
	}
	ft_echo2(cmd, fd);
}

void	ft_env(t_var *vars, char **cmd)
{
	int	i;

	i = 0;
	if (cmd[1])
	{
		printf("env: %s: No such file or directory\n", cmd[1]);
		g_err = 127;
		exit(g_err);
	}
	while (vars->env_var[i])
	{
		if (ft_strchr(vars->env_var[i], '='))
			printf("%s\n", vars->env_var[i]);
		i++;
	}
	g_err = 0;
	exit(g_err);
}
