/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_handle_dollar.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nali <nali@42abudhabi.ae>                  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/06 05:44:55 by nali              #+#    #+#             */
/*   Updated: 2022/06/22 17:31:19 by nali             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

/*------------- IF VARIABLE NAME WITHIN BRACES -------------*/
/*	If environment variable contains curly brace we have to 
	check for closing braces. If not found exit the program.*/
/*	If closing braces prsent, extract variable name from within
	the braces.
	Else, exit with syntax error*/
char	*ft_substr_brace(char *first, char *str, int *p)
{
	char	*sub;
	int		start_brace;
	int		j;

	j = *p;
	start_brace = j;
	while (str[j] != '}' && str[j])
		j++;
	if (str[j] != '}')
	{
		if (first != NULL)
			free(first);
		sub = NULL;
		printf("minishell: Syntax Error: no closing brace.\n");
	}
	else
		sub = ft_substr(str, start_brace + 1, j - start_brace - 1);
	*p = j;
	return (sub);
}

/*------------- SPECIAL CASES -------------*/
/*	$? should print g_err(exit status)
	$+ and $+ will be printed as it is*/
char	*ft_handle_special_cases(char *str, char *result, int i)
{
	if (str[i] == '?')
	{
		result = (char *)malloc(2);
		if (!result)
		{
			ft_malloc_error();
			return (NULL);
		}
		result[0] = '?';
		result[1] = '\0';
	}
	else if ((str[i] == '=' || str[i] == '+'))
	{
		result = (char *)malloc(3);
		if (!result)
		{
			ft_malloc_error();
			return (NULL);
		}
		result[0] = '$';
		result[1] = str[i];
		result[2] = '\0';
	}
	return (result);
}

/*------------- IF VARIABLE NAME NOT WITHIN BRACES -------------*/
/*	p - starting position of variable name

	Environment variable names consists solely of uppercase letters,
	digits, and the '_' (underscore) and do not begin with a digit. 
	To extract variable name starting from starting position and read till
	it encounters a value other than those mentioned above 
	
	After geting the variable name set i to last character of the variable name
	*/
char	*ft_substr_no_brace(char *str, int *p)
{
	int		l;
	char	*result;
	int		i;

	l = 0;
	i = *p;
	result = NULL;
	if (str[i] && (str[i] == '=' || str[i] == '+' || str[i] == '?'))
	{
		result = ft_handle_special_cases(str, result, i);
		return (result);
	}
	while (ft_isalnum(str[i + l]) || str[i + l] == '_')
		l++;
	result = ft_substr(str, i, l);
	if (!*result)
		*p = i;
	else
	{
		i = i + l - 1;
		*p = i;
	}
	return (result);
}

/*------------- EXPANDS ENV VARIABLES -------------*/
/*	Checks for variable name after $ and substitutes it with value of the
	environment variable returns NULL if no such environment variable exists*/
/*	A variable can be of the format $VAR or ${VAR}

	p is the position of the character after $
		if p = 0 or p = 1,there will not be any chararcters before $ 
		example: $SHELL or ${SHELL}
		if p > 1, chararcters before $ will be stored in first
		example:  123${SHELL}  or "${SHELL}"
		
	Check if variable has curly braces in variable name. If yes, extract the 
	variable name between the braces
	
	Get the environment variable value to be substitued and join with first
	
	If characters exist after the variable name, we have to join that also with
	the result.
	example: echo ${SHELL}123 --> gives output --> /bin/zsh123
	example: echo "$SHELL"abc --> gives output --> "/bin/zsh"abc*
	
	flag set to one in case there are braces*/
char	*ft_handle_dollar(char *str, int p, t_var *vars)
{
	char	*var_name;
	char	*sub_str;
	char	*first;
	char	*result;
	int		flag;

	first = NULL;
	flag = 0;
	if (p > 1)
		first = ft_substr(str, 0, p - 1);
	if (str[p] == '{')
	{
		flag = 1;
		var_name = ft_substr_brace(first, str, &p);
	}
	else
		var_name = ft_substr_no_brace(str, &p);
	if (flag == -1)
		return (NULL);
	sub_str = ft_get_envp_val(var_name, vars, &flag);
	result = ft_strjoin_new(first, sub_str);
	if (str[++p])
		result = ft_strjoin_new(result, ft_substr(str, p, ft_strlen(str) - p));
	return (result);
}
