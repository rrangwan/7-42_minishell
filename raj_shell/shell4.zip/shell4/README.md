# minishell
### Summary
```
The objective of this project is for you to create a simple shell.  
Yes, your little bash or zsh. You will learn a lot about processes and file descriptors.

(프로세스와 파일 디스크립터에 대한 이해를 바탕으로 bash, zsh과 같은 shell을 만드는 과제입니다.)
```
